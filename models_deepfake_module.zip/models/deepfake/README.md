# Acoustic Deepfake Detector (`models/deepfake/`)

Owner: Vansh. Scope: acoustic voice/deepfake detection only -- not the
backend, NLP, biometrics, or frontend layers of TrueVox.

## What this is

A wrapper around the official **AASIST-L** anti-spoofing model
([clovaai/aasist](https://github.com/clovaai/aasist), MIT license) that
takes a 2-second raw-audio window and returns a synthetic-speech
probability, for [Ansh]'s backend to fuse into the overall fraud risk
score.

## Model: why AASIST-L

Considered AASIST, AASIST-L, RawNet2, and Wav2Vec2/SSL-based detectors.
Picked **AASIST-L** because:

- It's the official pretrained checkpoint from the paper's authors
  (NAVER Corp), not a third-party reproduction -- provenance is clear.
- MIT-licensed, so it's fine to bundle and ship.
- ~85K parameters (vs ~298K for full AASIST, and orders of magnitude more
  for SSL/Wav2Vec2 models) -- realistic for the project's CPU real-time
  constraint. Full AASIST is only marginally more accurate on the
  official benchmark (0.99% vs 0.83% EER on ASVspoof2019 LA) for a much
  bigger model, so the lightweight variant is the better trade for this
  project.
- RawNet2 (the ASVspoof2021 baseline) reports weaker benchmark numbers
  than AASIST/AASIST-L on the same evaluation sets.

**Honest limitation:** the checkpoint was trained on ASVspoof2019 LA --
synthetic/converted speech from ~19 academic TTS/voice-conversion
systems, mostly English, studio-quality source audio. It was **not**
trained on real phone-call audio or on modern commercial voice-cloning
tools. Its own reported out-of-domain numbers (ASVspoof2021 LA: 13.15%
EER, ASVspoof2021 DF: 15.96% EER) are a more honest expectation for this
project than the in-domain 0.99%. We have not yet measured its accuracy
on our own real/synthetic hackathon test data -- do that with `eval.py`
before trusting any number in a demo.

## Files

| File | Purpose |
|---|---|
| `detector.py` | Public `AcousticDeepfakeDetector` class (`predict`, `predict_async`) |
| `backend_adapter.py` | Drop-in replacement for Ansh's `analyze_acoustic_artifacts` stub |
| `preprocess.py` | Validates/converts raw PCM16 bytes (streaming path) or WAV files (test-data path) |
| `features.py` | Pads/tiles audio to AASIST-L's required fixed length (64600 samples) |
| `model_adapter.py` | Loads the AASIST-L architecture + checkpoint, runs inference |
| `_aasist_arch.py` | Vendored copy of the official model architecture (MIT, see header) |
| `weights/AASIST-L.pth` | Official pretrained checkpoint (see `weights/AASIST_LICENSE`) |
| `eval.py` | Accuracy/precision/recall/F1/confusion-matrix/FPR/FNR on labeled test data |
| `benchmark_latency.py` | Measures real preprocessing + inference latency |

## Setup

```bash
pip install torch --index-url https://download.pytorch.org/whl/cpu
pip install numpy soundfile
```

(`torch` couldn't be installed in the sandbox this was built in -- ran out
of disk space fetching a GPU build from PyPI. Install the CPU-only build
from the official index above on your own machine, and run everything
below there.)

## Running inference

```python
from models.deepfake.detector import AcousticDeepfakeDetector

detector = AcousticDeepfakeDetector()
result = await detector.predict_async(audio_bytes)  # raw PCM16, 16kHz mono
# {
#     "synthetic_probability": 0.87,
#     "artifact_flags": [],
#     "model_name": "AASIST-L",
#     "inference_ms": 142.5,
#     "error": None,
# }
```

`synthetic_probability` is a softmax-derived score (spoof-class logit vs
bonafide-class logit), not a number the checkpoint was calibrated to
produce as a literal probability -- treat it as a ranking score until you
calibrate a decision threshold on your own test data (see `eval.py`,
`DECISION_THRESHOLD`).

## Backend handoff

Ansh's current stub in `app/pipeline/deepfake.py`:

```python
async def analyze_acoustic_artifacts(audio_bytes: bytes) -> float:
    # TODO (Vansh): Run ONNX/Wav2Vec2 model
    return 0.15
```

To use the real detector, change the import to:

```python
from models.deepfake.backend_adapter import analyze_acoustic_artifacts
```

No other changes needed -- same function name, same signature (`bytes ->
float`), so `app/main.py`'s `asyncio.gather(...)` call keeps working as-is.

## Testing

Put labeled WAV files under:

```
models/deepfake/test_data/real/*.wav
models/deepfake/test_data/synthetic/*.wav
```

Then run:

```bash
python -m models.deepfake.eval \
    --real-dir models/deepfake/test_data/real \
    --synthetic-dir models/deepfake/test_data/synthetic
```

This reports accuracy, precision, recall, F1, confusion matrix, false
positive rate, and false negative rate on your data -- not on the paper's
benchmark. A single correctly-classified clip proves nothing; evaluate on
a reasonably sized, unseen set, and look at the confusion matrix, not just
top-line accuracy. When testing "difficult cases" (background noise,
compression, different mics/speakers/accents, short clips), organize
those as labeled subfolders and run `eval.py` on each separately so
problems don't average out and hide.

Only use synthetic demo audio you have rights to (e.g. your own
open-source TTS output) for testing -- never clone a real person's voice
without their permission, even for a hackathon demo.

## Benchmarking latency

```bash
python -m models.deepfake.benchmark_latency --n 100
```

Reports actual measured preprocessing and total (preprocess + inference)
time on synthetic noise windows by default, or pass `--wav path/to/file`
to benchmark on real audio content. Don't claim a latency number in the
pitch deck that this script didn't just print on your own machine.
Optimize (ONNX export, quantization, avoiding repeated model loads --
already handled by the singleton in `backend_adapter.py`) only after
correctness is verified with `eval.py`.

## Git

Branch: `feature/acoustic-deepfake`. Changes scoped to `models/deepfake/`
and the two new top-level `models/__init__.py` / `models/deepfake/`
files -- nothing outside that touched.
